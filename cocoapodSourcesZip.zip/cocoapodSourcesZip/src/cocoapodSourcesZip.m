#include "cocoapodSourcesZip.h"

NSString* cocoapodSourcesZip() {
    return @"cocoapodSourcesZip";
}
