#import <Foundation/Foundation.h>

NSString* cocoapodSourcesZip(void);
